USE cryptopunk;
SHOW Tables;
SELECT * FROM cryptopunkdata;
SELECT * FROM pricedata;

# 01
SELECT COUNT(*) AS total_count
FROM pricedata;

#02
SELECT name, eth_price, usd_price, event_date
FROM pricedata
ORDER BY usd_price DESC
LIMIT 5;

#03
SELECT event_date, usd_price, avg(usd_price)
over(order by event_date rows between 49 preceding and current row) AS moving_avg
FROM pricedata
WHERE event_date BETWEEN '2018-01-01' AND '2021-12-31';

#04
SELECT name, AVG(usd_price) AS average_price
FROM pricedata
GROUP BY name
ORDER BY average_price DESC;

#05
SELECT WEEKDAY(event_date) AS DAYS, COUNT(usd_price) AS number_of_sales, AVG(eth_price)
FROM pricedata
GROUP BY DAYS
ORDER BY COUNT(usd_price);

#06
SELECT CONCAT( name," was sold for ",
 "$", usd_price, " to ",
 buyer_address, " from ",
 seller_address, " on ",
 event_date)
AS summary
FROM pricedata;

#07
CREATE VIEW 1919_purchases AS
SELECT * FROM pricedata
WHERE seller_address = '0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685'
						OR buyer_address = '0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685'
                        OR token_id = '0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685';
SHOW tables;
select * FROM 1919_purchases;

#08
SELECT ROUND(eth_price, -2) AS ETH_Range, COUNT(*) AS COUNT,
RPAD('', COUNT(*), '*') AS Bar FROM pricedata
GROUP BY ROUND(eth_price, -2)
ORDER BY ETH_Range;

#09
SELECT name, MAX(usd_price) AS price,
'highest' AS status
FROM pricedata
GROUP BY name
UNION
SELECT name, MIN(usd_price) AS price,
'lowest' AS status
FROM pricedata
GROUP BY name
ORDER BY name, status;

#10
SELECT month(event_date) AS month, year(event_date) AS year,
MAX(usd_price) AS max_price
FROM pricedata
GROUP BY month, year
ORDER BY year, month;

#11
SELECT month(event_date) AS month, year(event_date) AS year,
ROUND(SUM(usd_price), -2) AS total_volume
FROM pricedata
GROUP BY year, month
ORDER BY year, month;

#12
SELECT COUNT(*) AS no_of_transactions
FROM pricedata
WHERE seller_address = '0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685'
						OR buyer_address = '0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685'
                        OR token_id = '0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685';

#13-(a)
CREATE TEMPORARY TABLE DailyAverage AS(
SELECT
	event_date, usd_price,
	AVG(usd_price) OVER(PARTITION BY event_date) AS daily_avg_usd_price
FROM pricedata
);

#13(b)
SELECT event_date,
	AVG(usd_price) AS estimated_avg_usd_price
FROM DailyAverage 
WHERE usd_price >= 0.1*daily_avg_usd_price
GROUP BY event_date;

#14
SELECT 
    wallet_address,
    SUM(profit_loss) AS total_profit_loss
FROM (
    SELECT 
        token_id AS wallet_address,
        (usd_price - eth_price) AS profit_loss
    FROM 
        pricedata
    UNION ALL
    SELECT 
        seller_address AS wallet_address,
        (eth_price - usd_price) AS profit_loss
    FROM 
        pricedata
) AS profits_losses
GROUP BY 
    wallet_address
ORDER BY 
    total_profit_loss DESC;




